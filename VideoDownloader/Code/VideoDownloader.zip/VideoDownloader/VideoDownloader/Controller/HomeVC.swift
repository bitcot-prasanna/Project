//
//  ViewController.swift
//  VideoDownloader
//
//  Created by apple on 12/05/22.
//

import UIKit
import Alamofire

class HomeVC: UIViewController {

    @IBOutlet weak var tblVideoList: UITableView!
    
    var progressShow:Float = 0.0
    var btnTitleText = "Downloads"
    var arrVideoData = [Any]()
    var dictVideoData = [String:Any]()
    var btnTappedIndex:Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblVideoList.register(UINib(nibName: "VideoCell", bundle: nil), forCellReuseIdentifier: "VideoCell")
        self.createFileDirectory()
        self.linkCreation()
        // Do any additional setup after loading the view.
    }
}

//MARK: - Table view DS and Delegate
extension HomeVC:UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrVideoData.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblVideoList.dequeueReusableCell(withIdentifier: "VideoCell", for: indexPath) as! VideoCell
        let dataExtract = arrVideoData[indexPath.row] as! [String:Any]
        cell.btnAction.tag = indexPath.row
        cell.lblTitle.text = dataExtract["title"] as? String
        cell.delegate = self
                cell.download = {
                    self.downloadVideo()
                }
            cell.progressBar.progress = self.progressShow
            cell.btnAction.setTitle(self.btnTitleText, for: UIControl.State.normal)
        return cell
    }
}


//MARK: Download video network call
extension HomeVC{
    func downloadVideo(){
        let dataExtract = arrVideoData[self.btnTappedIndex] as! [String:Any]
        let urlData = dataExtract["urlData"] as! String
        let title = "Video\((dataExtract["indexNumber"] as! Int)+1)"
        let destination: DownloadRequest.Destination = { _, _ in
            let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("VideoDownloaderApp")
            let fileURL = documentsURL.appendingPathComponent(title).appendingPathExtension("mp4")
            return (fileURL, [.removePreviousFile, .createIntermediateDirectories])
        }
        AF.download(urlData, to: destination).downloadProgress { progress in
            print("Download Progress: \(progress.fractionCompleted)")
            self.progressShow = Float(progress.fractionCompleted)
        }.response{ response in
            print("Response Data::::::",response)
            if response.error == nil, let imagePath = response.fileURL?.path {
                print(imagePath)
                self.btnTitleText = "Delete"
                self.tblVideoList.reloadData()
//                let image = UIImage(contentsOfFile: imagePath)
//                print("imagePath",imagePath)
//                self.imgThumbnail.image = image
                
            }
        }
    }
}


//MARK: - create app directory to store videos
extension HomeVC{
    func createFileDirectory() {
        let documentsURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            let folderURL = documentsURL.appendingPathComponent("VideoDownloaderApp")
        do
        {
            if !FileManager.default.fileExists(atPath: folderURL.path){
                try FileManager.default.createDirectory(at: folderURL, withIntermediateDirectories: true)
            }
        }
        catch let error as NSError
        {
            NSLog("Unable to create directory \(error.debugDescription)")
        }
    }
}

//MARK: - define data to get
extension HomeVC{
    func linkCreation(){
        let arrURL = ["https://player.vimeo.com/external/451569305.m3u8?s=c7da8176e60471cc9c51156ae3f35fc2c62ce72f"
                      ,"https://player.vimeo.com/external/433925279.m3u8?s=8930e1062fd90896c870a234a018a66ef544e74d"
                      ,"https://player.vimeo.com/external/432904528.m3u8?s=2eea9d6430a2ee2c760701e34178352b693b3f1b"
                      ,"https://player.vimeo.com/external/432902374.m3u8?s=ca1aabae12ccb24bfb83def94fa3ee6e38d939ae"
                      ,"https://player.vimeo.com/external/433664412.m3u8?s=a511c3907db8d1832de247987b28ce1ac788763b"]
        for index in 0..<5{
            self.dictVideoData["indexNumber"] = index
            self.dictVideoData["title"] = "Title \(index + 1)"
            self.dictVideoData["urlData"] = arrURL[index]
            self.arrVideoData.append(dictVideoData)
        }
        print(arrVideoData)
    }
}

extension HomeVC : btnCellIndex{
    func cellIndex(tag: Int) {
        self.btnTappedIndex = tag
    }
}
