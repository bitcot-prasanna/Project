//
//  UIColor+Extension.swift
//  VideoDownloader
//
//  Created by apple on 12/05/22.
//

import Foundation
import UIKit

extension UIColor{
    static let App_Red = "App_Red"
    static let App_LightRed = "App_LightRed"
}
