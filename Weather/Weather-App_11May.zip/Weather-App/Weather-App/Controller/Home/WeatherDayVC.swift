//
//  ViewController.swift
//  Weather-App
//
//  Created by admin on 04/05/22.
//

import UIKit
import SDWebImage
import CoreLocation

class WeatherDayVC: UIViewController {
    
    @IBOutlet weak var lblCityName : UILabel!
    @IBOutlet weak var lblCountryName : UILabel!
    
    @IBOutlet weak var imgCurrentDayFC : UIImageView!
    @IBOutlet weak var lblCurrentDayFC : UILabel!
    @IBOutlet weak var lblSubtitleFC : UILabel!
    @IBOutlet weak var lblFCDegree : UILabel!
    
    @IBOutlet weak var lblWindVal : UILabel!
    @IBOutlet weak var lblFeelsLikeVal : UILabel!
    @IBOutlet weak var lblIndexVal : UILabel!
    @IBOutlet weak var lblPressureVal : UILabel!
    
    @IBOutlet weak var collWholeDay : UICollectionView!
    
    @IBOutlet weak var btnNext7DayFC : UIButton!
    
    @IBOutlet weak var activityIndicator : UIActivityIndicatorView!
    
    
    let locationManager = CLLocationManager()
    
    var weatherResponse = [WeatherModel]()
    var forecastResponse = [ForecastModel]()
    let defaultIndex = 0
    
    
    var cordinate : CLLocationCoordinate2D!
    
    var selectedForcast : Hourly!{
        didSet{
            self.setupViewData()
        }
    }
    
    var selectedIndex = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //register collection view
        self.activityIndicator.startAnimating()
        collWholeDay.register(UINib.init(nibName: "WeatherDayCell", bundle: nil), forCellWithReuseIdentifier: "WeatherDayCell")
        //next 7 days forcast button disable for interaction until get data to pass
        self.btnNext7DayFC.isUserInteractionEnabled = false
        setupLocationManager()
        
        // Do any additional setup after loading the view.
    }
}

//MARK: - get location and calling function containing api.
extension WeatherDayVC : CLLocationManagerDelegate{
    
    func setupLocationManager(){
        locationManager.delegate = self
        locationManager.requestAlwaysAuthorization()
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.first{
            cordinate = location.coordinate
            self.getCurrentWeatherData()
            self.getWholeWeekWeatherData()
        }
    }
}

//MARK: - Setup main visible view.
extension WeatherDayVC{
    func setupViewData(){
        if selectedForcast != nil{
            if  let icon = selectedForcast.weather.first?.icon.iconAsUrl(){
                self.imgCurrentDayFC.sd_setImage(with: icon, placeholderImage: nil)
                self.imgCurrentDayFC.backgroundColor = .clear
            }
            self.lblFCDegree.text = selectedForcast.temp.temperatureConversionFormatterWithDegree()
            self.lblCurrentDayFC.text = selectedForcast.weather.first?.description
            self.lblWindVal.text = (selectedForcast.wind_speed.description) + "km/j"
            self.lblFeelsLikeVal.text = selectedForcast.feels_like.temperatureConversionFormatterWithDegree()
            self.lblPressureVal.text = (selectedForcast.pressure.description) + "mbar"
            self.lblSubtitleFC.text = selectedForcast.dt.getFinalFormattedDate(formatType: DateFormatterType.DateFormatterKeys.DayDateMonth.rawValue)
            self.lblIndexVal.text = weatherResponse[defaultIndex].sys.sunrise.getFinalFormattedDate(formatType: DateFormatterType.DateFormatterKeys.HourMinute.rawValue)
            self.lblCityName.text = weatherResponse[defaultIndex].name
            self.lblCountryName.text = "," + (weatherResponse[defaultIndex].sys.country)
        }
        
    }
}

//MARK: - navigate to next vc to see 7 days forecast.
extension WeatherDayVC {
    
    @IBAction func actionOnNext7Days(_ button : UIButton){
        if let vc = self.storyboard?.instantiateViewController(withIdentifier: "ForeCastVC") as? ForeCastVC{
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            vc.arrWholeWeekData = self.forecastResponse[defaultIndex].daily
            vc.titleCity = weatherResponse[defaultIndex].name
            vc.titleCountry = "," + (weatherResponse[defaultIndex].sys.country)
            self.present(vc, animated: true, completion: nil)
        }
    }
}

//MARK: - setup collection view and it's method
extension WeatherDayVC:UICollectionViewDelegateFlowLayout,UICollectionViewDataSource,UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: view.frame.size.width/7.13, height :view.frame.size.height/8.26) //428.00,926.00
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return forecastResponse.count == 0 ? 0 : forecastResponse[defaultIndex].hourly.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collWholeDay.dequeueReusableCell(withReuseIdentifier: "WeatherDayCell", for: indexPath ) as! WeatherDayCell
        cell.viewContainer.backgroundColor = selectedIndex == indexPath.row ? UIColor.app_color_activeBlue : .clear
        let hourlyData = indexPath.row == 0 ? forecastResponse[defaultIndex].current : forecastResponse[defaultIndex].hourly[indexPath.row - 1]
        
        if let weather =  hourlyData.weather.first{
            let icon = weather.icon.iconAsUrl()
            cell.imageViewIcon.sd_setImage(with: icon, placeholderImage: nil)
        }
        
        cell.labelTemperature.text = hourlyData.temp.temperatureConversionFormatterWithDegree()
        cell.labelHours.text = indexPath.row == 0 ? "Now" : hourlyData.dt.getFinalFormattedDate(formatType: DateFormatterType.DateFormatterKeys.HourMinute.rawValue)
        cell.labelHours.textColor = selectedIndex == indexPath.row ? .white : .black
        cell.labelTemperature.textColor = selectedIndex == indexPath.row ? .white : .black
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        self.selectedIndex = indexPath.row
        self.selectedForcast = self.forecastResponse[defaultIndex].hourly[indexPath.row]
        self.collWholeDay.reloadData()
    }
}

//MARK: - API calling by function
extension WeatherDayVC {
    func getCurrentWeatherData(){
        let parameter  : [String : Any] = ["lat": cordinate
            .latitude.description, "lon": cordinate.longitude.description  , "appId" : appId]
        Networking.shared.getData(endPoint: Endpoints.weather.rawValue, parameter: parameter) { (data, error) in
            if let tempData = data{
                let jsonDecoder = JSONDecoder()
                let response = try! jsonDecoder.decode(WeatherModel.self, from: tempData)
                self.weatherResponse = [response]
                self.setupViewData()
            }
        }
        
    }
    
    func getWholeWeekWeatherData(){
        let parameter  : [String : Any] = ["lat": cordinate.latitude.description , "lon": cordinate.longitude.description  , "appId" : appId]
        Networking.shared.getData(endPoint: Endpoints.onCall.rawValue, parameter: parameter) { (data, error) in
            if let tempData = data{
                let jsonDecoder = JSONDecoder()
                let response = try! jsonDecoder.decode(ForecastModel.self, from: tempData)
                self.forecastResponse = [response]
                
                self.collWholeDay.reloadData()
                self.activityIndicator.stopAnimating()
                self.btnNext7DayFC.isUserInteractionEnabled = true
                self.activityIndicator.isHidden = true
                if self.forecastResponse.count != 0{
                    self.selectedForcast = self.selectedIndex == 0 ?  self.forecastResponse[self.defaultIndex].current : ((self.forecastResponse[self.defaultIndex].hourly.count) - 1 == self.selectedIndex ?  self.forecastResponse[self.defaultIndex].hourly[self.selectedIndex] : self.forecastResponse[self.defaultIndex].hourly[self.selectedIndex + 1])
                }
            }
        }
    }
}
