//
//  WholeWeekFCCell.swift
//  Weather-App
//
//  Created by admin on 05/05/22.
//

import UIKit

class WholeWeekFCCell: UITableViewCell {

    @IBOutlet weak var imgDay: UIImageView!
    @IBOutlet weak var lblDay: UILabel!
    @IBOutlet weak var lblDateMonth: UILabel!
    @IBOutlet weak var lblMinTemp: UILabel!
    @IBOutlet weak var lblMaxTemp: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
