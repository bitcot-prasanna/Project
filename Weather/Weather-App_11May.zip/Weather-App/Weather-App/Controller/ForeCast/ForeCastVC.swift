//
//  ForeCastVC.swift
//  Weather-App
//
//  Created by admin on 04/05/22.
//

import UIKit
import SDWebImage

class ForeCastVC: UIViewController {
    @IBOutlet weak var lblCityTitle : UILabel!
    @IBOutlet weak var lblCountryTitle : UILabel!
    @IBOutlet weak var tblWeeklyFC : UITableView!
    
    //MARK: - declare below vcr to get data from first vc to replicate into this vc.
    var arrWholeWeekData = [Daily]()
    var titleCity = ""
    var titleCountry = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblWeeklyFC.register(UINib.init(nibName: "WholeWeekFCCell", bundle: nil), forCellReuseIdentifier: "WholeWeekFCCell")
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setUpHeader()
    }
}

//MARK: - action to dismiss from current vc
extension ForeCastVC{
    @IBAction func btnBackTapped(_ sender : UIButton){
        self.dismiss(animated: true)
    }
}

//MARK: - Definition of header setup function
extension ForeCastVC{
    func setUpHeader(){
        self.lblCityTitle.text = titleCity
        self.lblCountryTitle.text = titleCountry
        self.tblWeeklyFC.reloadData()
    }
}

//MARK: - Table view methods
extension ForeCastVC:UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return view.frame.height/14
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrWholeWeekData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "WholeWeekFCCell",for: indexPath) as! WholeWeekFCCell
        let objArrWholeWeekFC = arrWholeWeekData[indexPath.row]
        cell.lblDay.text = objArrWholeWeekFC.dt.getFinalFormattedDate(formatType: DateFormatterType.DateFormatterKeys.Day.rawValue)
        cell.lblDateMonth.text = "," + objArrWholeWeekFC.dt.getFinalFormattedDate(formatType: DateFormatterType.DateFormatterKeys.DateMonth.rawValue)
        cell.lblMaxTemp.text = "/" + objArrWholeWeekFC.temp.max.temperatureConversionFormatterWithDegree()
        cell.lblMinTemp.text = objArrWholeWeekFC.temp.min.temperatureConversionFormatterWithoutDegree()
        
        if let weather =  objArrWholeWeekFC.weather.first{
            let icon = weather.icon.iconAsUrl()
            cell.imgDay.sd_setImage(with: icon, placeholderImage: nil)
        }
        return cell
    }
}
