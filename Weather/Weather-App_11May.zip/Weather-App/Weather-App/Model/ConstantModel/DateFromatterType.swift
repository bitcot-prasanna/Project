//
//  DateFromatterType.swift
//  Weather-App
//
//  Created by apple on 11/05/22.
//

import Foundation

struct DateFormatterType{
    let DayDateMonth : String
    let HourMinute : String
    let Day : String
    let DateMonth : String
    
    enum DateFormatterKeys : String{
        case DayDateMonth = "EEEE, d MMM"
        case HourMinute = "hh:mm"
        case Day = "EEEE"
        case DateMonth = "d MMM"
    }
}
