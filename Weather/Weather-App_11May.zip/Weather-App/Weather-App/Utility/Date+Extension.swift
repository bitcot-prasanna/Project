//
//  ForeCastVC.swift
//  Weather-App
//
//  Created by admin on 04/05/22.
//

import Foundation
import UIKit

//MARK: - get date formatter
extension Date {
     func getFormattedDate(formatter:String) -> String{
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: TimeZone.current.identifier)
        dateFormatter.dateFormat = formatter
        return dateFormatter.string(from: self)

    }
}


//MARK: - get view extension to give border width and corner radius
@IBDesignable extension UIView {
    @IBInspectable var borderColor:UIColor? {
        set {
            layer.borderColor = newValue!.cgColor
        }
        get {
            if let color = layer.borderColor {
                return UIColor(cgColor: color)
            }
            else {
                return nil
            }
        }
    }
    @IBInspectable var borderWidth:CGFloat {
        set {
            layer.borderWidth = newValue
        }
        get {
            return layer.borderWidth
        }
    }
    @IBInspectable var cornerRadius:CGFloat {
        set {
            layer.cornerRadius = newValue
            clipsToBounds = newValue > 0
        }
        get {
            return layer.cornerRadius
        }
    }
}

//MARK: - to set color
extension UIColor {
    
    static let app_color_activeBlue = UIColor(named: "app_color_activeBlue")
    
    convenience init(_ hex: String, alpha: CGFloat = 0.88) {
        var cString = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if cString.hasPrefix("#") { cString.removeFirst() }
        
        if cString.count != 6 {
            self.init("ff0000") 
            return
        }
        
        var rgbValue: UInt64 = 0
        Scanner(string: cString).scanHexInt64(&rgbValue)
        
        self.init(red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
                  green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
                  blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
                  alpha: alpha)
    }

}
