//
//  ForeCastVC.swift
//  Weather-App
//
//  Created by admin on 04/05/22.
//

import Foundation
import Alamofire

let baseUrl : String = "https://api.openweathermap.org/data/2.5/"
let appId = "902cf6d0ac9f8ad8b5c115fcccf9416d"

enum Endpoints  : String{
    case weather = "weather"
    case onCall = "onecall"
}


typealias WeatherAppResponse = ((_ data : Data? , _ error : Error?)->Void)


class Networking {
    
    static let shared = Networking()
    
    
    func getData(endPoint : String ,parameter : Parameters , completionHandler : @escaping WeatherAppResponse){
        let url = baseUrl + endPoint
        AF.request(url, method: .get, parameters: parameter, encoding: URLEncoding.default, headers: nil).response { response in
            completionHandler(response.data , response.error)
        }
    }
}
