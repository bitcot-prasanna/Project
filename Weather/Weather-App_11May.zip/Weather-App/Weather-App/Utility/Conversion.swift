//
//  ForeCastVC.swift
//  Weather-App
//
//  Created by admin on 04/05/22.
//

import Foundation

extension Double {
    //date formatter
    func getFinalFormattedDate(formatType:String) -> String{
        return Date(timeIntervalSince1970: self).getFormattedDate(formatter: formatType)
    }
    //convert with degree
    func temperatureConversionFormatterWithDegree() -> String{
           return String(format: "%.0f°", self.fahrenheitToCelsius())
    }
    //convert w/o degree
    func temperatureConversionFormatterWithoutDegree() -> String{
           return String(format: "%.0f", self.fahrenheitToCelsius())
    }
    
    // Convert from F to C (Double)
    func fahrenheitToCelsius() ->Double {
        let celsius = (self - 32.0) * (5.0/9.0)
        return celsius as Double
    }
    // Convert from C to F (Integer)
    func celsiusToFahrenheit() ->Double {
        let fahrenheit = (self * 9.0/5.0) + 32.0
        return fahrenheit as Double
    }
    // Convert from miles to kilometers (Double)
    func milesToKilometers() ->Double {
        let speedInKPH = self * 1.60934
        return speedInKPH as Double
    }
    
    // Convert from kilometers to miles (Double)
    func kilometersToMiles() ->Double {
        let speedInKPH = self / 1.60934
        return speedInKPH as Double
    }
    
    // Convert from inches to cm
    func inchesToCentimeters() ->Double {
        let depthInCentimeters = self * 2.54
        return depthInCentimeters as Double
    }
    
    // Convert from cm to inches
    func centimetersToInches() ->Double {
        let depthInInches = self / 2.54
        return depthInInches as Double
    }
    
}


extension String{
    func iconAsUrl()->URL{
        return URL(string: "https://openweathermap.org/img/wn/\(self).png")!
    }
}
