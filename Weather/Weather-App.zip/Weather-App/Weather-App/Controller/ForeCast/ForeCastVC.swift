//
//  ForeCastVC.swift
//  Weather-App
//
//  Created by admin on 04/05/22.
//

import UIKit
import SDWebImage

class ForeCastVC: UIViewController {
    @IBOutlet weak var lblCityTitle : UILabel!
    @IBOutlet weak var lblCountryTitle : UILabel!
    @IBOutlet weak var tblWeeklyFC : UITableView!
    
    //MARK: - declare below vcr to get data from first vc to replicate into this vc.
    var arrWholeWeekData : [Daily]?
    var titleCity = ""
    var titleCountry = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tblWeeklyFC.register(UINib.init(nibName: "WholeWeekFCCell", bundle: nil), forCellReuseIdentifier: "WholeWeekFCCell")
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setUpHeader()
    }
}

//MARK: - action to dismiss from current vc
extension ForeCastVC{
    @IBAction func btnBackTapped(_ sender : UIButton){
        self.dismiss(animated: true)
    }
}

//MARK: - Definition of header setup function
extension ForeCastVC{
    func setUpHeader(){
        self.lblCityTitle.text = titleCity
        self.lblCountryTitle.text = titleCountry
        self.tblWeeklyFC.reloadData()
    }
}

//MARK: - Table view methods
extension ForeCastVC:UITableViewDataSource,UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrWholeWeekData?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "WholeWeekFCCell",for: indexPath) as! WholeWeekFCCell
        if let timestamp =  arrWholeWeekData?[indexPath.row].dt{
            let date = Date.init(timeIntervalSince1970: timestamp)
            cell.lblDay.text = date.getFormattedDate(formatter: "EEEE")
            cell.lblDateMonth.text = "," +  date.getFormattedDate(formatter: "d MMM")
            cell.lblMaxTemp.text = "/" + String(format: "%.0f°", arrWholeWeekData?[indexPath.row].temp?.max?.fahrenheitToCelsius() ?? 0)
            cell.lblMinTemp.text = String(format: "%.0f", arrWholeWeekData?[indexPath.row].temp?.min?.fahrenheitToCelsius() ?? 0)
        }
        if let weather =  arrWholeWeekData?[indexPath.row].weather?.first{
            if  let icon = weather.icon , let url  = URL.init(string: "https://openweathermap.org/img/wn/\(icon).png"){
                cell.imgDay.sd_setImage(with: url, placeholderImage: nil)
            }
        }
        return cell
    }
}
