//
//  ViewController.swift
//  Weather-App
//
//  Created by admin on 04/05/22.
//

import UIKit
import SDWebImage
import CoreLocation

class ViewController: UIViewController {
    
    @IBOutlet weak var lblCityName : UILabel!
    @IBOutlet weak var lblCountryName : UILabel!
    
    @IBOutlet weak var imgCurrentDayFC : UIImageView!
    @IBOutlet weak var lblCurrentDayFC : UILabel!
    @IBOutlet weak var lblSubtitleFC : UILabel!
    @IBOutlet weak var lblFCDegree : UILabel!
    
    @IBOutlet weak var lblWindVal : UILabel!
    @IBOutlet weak var lblFeelsLikeVal : UILabel!
    @IBOutlet weak var lblIndexVal : UILabel!
    @IBOutlet weak var lblPressureVal : UILabel!
    
    @IBOutlet weak var collWholeDay : UICollectionView!
    
    @IBOutlet weak var activityIndicator : UIActivityIndicatorView!
    
    
    let locationManager = CLLocationManager()
    
    var weatherResponse : WeatherModel?
    var forecastResponse : ForecastModel?
    
    
    var cordinate : CLLocationCoordinate2D!
    
    var selectedForcast : Hourly?{
        didSet{
            self.setupViewData()
        }
    }
    
    var selectedIndex = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //MARK: - register collection view
        self.activityIndicator.startAnimating()
        collWholeDay.register(UINib.init(nibName: "WeatherDayCell", bundle: nil), forCellWithReuseIdentifier: "WeatherDayCell")
        setupLocationManager()
        // Do any additional setup after loading the view.
    }
}

//MARK: - get location and calling function containing api.
extension ViewController : CLLocationManagerDelegate{
    
    func setupLocationManager(){
        locationManager.delegate = self
        locationManager.requestAlwaysAuthorization()
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.first{
            cordinate = location.coordinate
            self.getCurrentWeatherData()
            self.getWholeWeekWeatherData()
        }
    }
}

//MARK: - Setup main visible view.
extension ViewController{
    func setupViewData(){
        if  let icon = selectedForcast?.weather?.first?.icon , let url  = URL.init(string: "https://openweathermap.org/img/wn/\(icon).png"){
            self.imgCurrentDayFC.sd_setImage(with: url, placeholderImage: nil)
            self.imgCurrentDayFC.backgroundColor = .clear
        }
        
        self.lblFCDegree.text = String(format: "%.0f°", selectedForcast?.temp?.fahrenheitToCelsius() ?? 0)
        self.lblCurrentDayFC.text = selectedForcast?.weather?.first?.description
        self.lblWindVal.text = (selectedForcast?.wind_speed?.description ?? "") + "km/j"
        self.lblFeelsLikeVal.text = String(format: "%.0f°", selectedForcast?.feels_like?.fahrenheitToCelsius() ?? 0)
        self.lblPressureVal.text = (selectedForcast?.pressure?.description ?? "" ) + "mbar"
        if  let timestamp = selectedForcast?.dt{
            self.lblSubtitleFC.text = Date.init(timeIntervalSince1970: timestamp).getFormattedDate(formatter: "EEEE, d MMM")
            
        }
        
        if  let timestamp = weatherResponse?.sys?.sunrise{
            self.lblIndexVal.text = Date.init(timeIntervalSince1970: timestamp).getFormattedDate(formatter: "hh:mm")
            
        }
        
        self.lblCityName.text = weatherResponse?.name
        self.lblCountryName.text = "," + (weatherResponse?.sys?.country ?? "")
        
    }
}

//MARK: - navigate to next vc to see 7 days forecast.
extension ViewController {
    
    @IBAction func actionOnNext7Days(_ button : UIButton){
        if let vc = self.storyboard?.instantiateViewController(withIdentifier: "ForeCastVC") as? ForeCastVC{
            vc.modalPresentationStyle = .fullScreen
            vc.modalTransitionStyle = .crossDissolve
            vc.arrWholeWeekData = self.forecastResponse?.daily
            vc.titleCity = weatherResponse?.name ?? ""
            vc.titleCountry = "," + (weatherResponse?.sys?.country ?? "")
            self.present(vc, animated: true, completion: nil)
        }
    }
}

//MARK: - setup collection view and it's method
extension ViewController:UICollectionViewDelegateFlowLayout,UICollectionViewDataSource,UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize.init(width: 60, height:100)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return forecastResponse?.hourly?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collWholeDay.dequeueReusableCell(withReuseIdentifier: "WeatherDayCell", for: indexPath ) as! WeatherDayCell
        cell.viewContainer.backgroundColor = selectedIndex == indexPath.row ? UIColor.init( "#007AFF" ) : .clear
        let hourlyData = indexPath.row == 0 ? forecastResponse?.current : forecastResponse?.hourly![indexPath.row - 1]
        
        if let weather =  hourlyData?.weather?.first{
            if  let icon = weather.icon , let url  = URL.init(string: "https://openweathermap.org/img/wn/\(icon).png"){
                cell.imageViewIcon.sd_setImage(with: url, placeholderImage: nil)
            }
        }
        
        if let timestamp  = hourlyData?.dt{
            cell.labelTemperature.text = String(format: "%.0f°", hourlyData?.temp?.fahrenheitToCelsius() ?? 0)
            cell.labelHours.text = indexPath.row == 0 ? "Now" : Date.init(timeIntervalSince1970: timestamp).getFormattedDate(formatter: "hh:mm")
            cell.labelHours.textColor = selectedIndex == indexPath.row ? .white : .black
            cell.labelTemperature.textColor = selectedIndex == indexPath.row ? .white : .black
            
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        self.selectedIndex = indexPath.row
        self.selectedForcast = self.forecastResponse?.hourly?[indexPath.row]
        self.collWholeDay.reloadData()
    }
}

//MARK: - API calling by function
extension ViewController {
    func getCurrentWeatherData(){
        let parameter  : [String : Any] = ["lat": cordinate
            .latitude.description, "lon": cordinate.longitude.description  , "appId" : appId]
        Networking.shared.getData(endPoint: Endpoints.weather.rawValue, parameter: parameter) { (data, error) in
            if let tempData = data{
                let jsonDecoder = JSONDecoder()
                self.weatherResponse = try! jsonDecoder.decode(WeatherModel.self, from: tempData)
                self.setupViewData()
            }
        }
        
    }
    
    func getWholeWeekWeatherData(){
        let parameter  : [String : Any] = ["lat": cordinate.latitude.description , "lon": cordinate.longitude.description  , "appId" : appId]
        Networking.shared.getData(endPoint: Endpoints.onCall.rawValue, parameter: parameter) { (data, error) in
            if let tempData = data{
                let jsonDecoder = JSONDecoder()
                self.forecastResponse = try! jsonDecoder.decode(ForecastModel.self, from: tempData)
                self.collWholeDay.reloadData()
                self.activityIndicator.stopAnimating()
                self.activityIndicator.isHidden = true
                self.selectedForcast = self.selectedIndex == 0 ?  self.forecastResponse?.current : ((self.forecastResponse?.hourly?.count ?? 0) - 1 == self.selectedIndex ?  self.forecastResponse?.hourly?[self.selectedIndex] : self.forecastResponse?.hourly?[self.selectedIndex + 1])
            }
        }
    }
}

