//
//  WeatherDayCell.swift
//  Weather-App
//
//  Created by admin on 04/05/22.
//

import UIKit

class WeatherDayCell: UICollectionViewCell {
    
    @IBOutlet weak var viewContainer: UIView!
    @IBOutlet weak var labelHours: UILabel!
    @IBOutlet weak var imageViewIcon: UIImageView!
    @IBOutlet weak var labelTemperature: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
