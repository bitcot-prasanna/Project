import Foundation
struct Hourly : Codable {
	let dt : Double?
	let temp : Double?
	let feels_like : Double?
	let pressure : Double?
	let humidity : Double?
	let dew_point : Double?
	let clouds : Double?
	let visibility : Double?
	let wind_speed : Double?
	let wind_deg : Double?
	let wind_gust : Double?
	let weather : [Weather]?

	enum CodingKeys: String, CodingKey {

		case dt = "dt"
		case temp = "temp"
		case feels_like = "feels_like"
		case pressure = "pressure"
		case humidity = "humidity"
		case dew_point = "dew_point"
		case clouds = "clouds"
		case visibility = "visibility"
		case wind_speed = "wind_speed"
		case wind_deg = "wind_deg"
		case wind_gust = "wind_gust"
		case weather = "weather"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		dt = try values.decodeIfPresent(Double.self, forKey: .dt)
		temp = try values.decodeIfPresent(Double.self, forKey: .temp)
		feels_like = try values.decodeIfPresent(Double.self, forKey: .feels_like)
		pressure = try values.decodeIfPresent(Double.self, forKey: .pressure)
		humidity = try values.decodeIfPresent(Double.self, forKey: .humidity)
		dew_point = try values.decodeIfPresent(Double.self, forKey: .dew_point)
		clouds = try values.decodeIfPresent(Double.self, forKey: .clouds)
		visibility = try values.decodeIfPresent(Double.self, forKey: .visibility)
		wind_speed = try values.decodeIfPresent(Double.self, forKey: .wind_speed)
		wind_deg = try values.decodeIfPresent(Double.self, forKey: .wind_deg)
		wind_gust = try values.decodeIfPresent(Double.self, forKey: .wind_gust)
		weather = try values.decodeIfPresent([Weather].self, forKey: .weather)
	}

}
