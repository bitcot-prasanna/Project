
import Foundation
struct Data : Codable {
	let _id : String?
	let name : String?
	let trips : Int?
	let airline : [Airline]?
	let __v : Int?

	enum CodingKeys: String, CodingKey {

		case _id = "_id"
		case name = "name"
		case trips = "trips"
		case airline = "airline"
		case __v = "__v"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		_id = try values.decodeIfPresent(String.self, forKey: ._id)
		name = try values.decodeIfPresent(String.self, forKey: .name)
		trips = try values.decodeIfPresent(Int.self, forKey: .trips)
		airline = try values.decodeIfPresent([Airline].self, forKey: .airline)
		__v = try values.decodeIfPresent(Int.self, forKey: .__v)
	}

}
