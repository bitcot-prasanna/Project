import Foundation
struct PaginationMain : Codable {
	let totalPassengers : Int?
	let totalPages : Int?
	let data : [Data]?

	enum CodingKeys: String, CodingKey {

		case totalPassengers = "totalPassengers"
		case totalPages = "totalPages"
		case data = "data"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		totalPassengers = try values.decodeIfPresent(Int.self, forKey: .totalPassengers)
		totalPages = try values.decodeIfPresent(Int.self, forKey: .totalPages)
		data = try values.decodeIfPresent([Data].self, forKey: .data)
	}

}
