//
//  ViewController.swift
//  PaginationDummy
//
//  Created by admin on 06/05/22.
//

import UIKit
import PaginatedTableView
import SDWebImage

class ViewController: UIViewController {
    
    @IBOutlet weak var tblPaginated : PaginatedTableView!

    //MARK: - declaring & Defining api paramerters
    var pageNumber = 0
    let fixedSize = 10
    
    //MARK: - Declaring variable of model type which stores data
    var airlineData:PaginationMain?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.basicConfigToTableView()
        // Do any additional setup after loading the view.
    }
}

//MARK: - register table view and give ds and delegets and calling function to load data
extension ViewController{
    func basicConfigToTableView(){
        self.getAirlineData()
        tblPaginated.register(UINib.init(nibName: "DataCell", bundle: nil), forCellReuseIdentifier: "DataCell")
        //MARK: - Add paginated delegates only
        tblPaginated.paginatedDelegate = self
        tblPaginated.paginatedDataSource = self
        //MARK: - More settings
        tblPaginated.enablePullToRefresh = true
        tblPaginated.pullToRefreshTitle = NSAttributedString(string: "Pull to Refresh")
        self.tblPaginated.loadData(refresh: true)
    }
}

extension ViewController: PaginatedTableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 180
    }
    
    func loadMore(_ pageNumber: Int, _ pageSize: Int, onSuccess: ((Bool) -> Void)?, onError: ((Error) -> Void)?) {
        // calling api when load controller once
        self.getAirlineData()
        
//        if pageNumber == 1 { self.list = [Int]() }
//
//        // else append the data to list
//        let startFrom = (self.list.last ?? 0) + 1
//        for number in startFrom..<(startFrom + pageSize) {
//            self.list.append(number)
//        }
//        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
//            onSuccess?(true)
//        }
//    }
       
    }
}


//MARK: - Paginated Data Source
extension ViewController: PaginatedTableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.airlineData?.data?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "DataCell", for: indexPath) as? DataCell else {
            fatalError("The dequeued cell is not an instance of TableViewCell.")
        }
        if self.airlineData?.data?.count != 0{
            cell.imgAirline.sd_setImage(with: URL(string: self.airlineData?.data?[indexPath.row].airline?[0].logo ?? ""), placeholderImage: nil)
            cell.lblName.text = self.airlineData?.data?[indexPath.row].name ?? ""
            cell.lblAirlineName.text = self.airlineData?.data?[indexPath.row].airline?[0].name
            cell.lblTrips.text = self.airlineData?.data?[indexPath.row].trips?.description
        }
        return cell
    }
    public func scrollViewDidScroll(_ scrollView: UIScrollView) {
        print(scrollView.contentOffset.y)
    }
}

//MARK: - defining function to call api
extension ViewController{
    func getAirlineData(){
        let parameter : [String : Any] = ["page":pageNumber,"size":fixedSize]
        Networking.shared.getData(parameter: parameter){ (data, error) in
            if let tempData = data{
                let jsonDecoder = JSONDecoder()
                self.airlineData = try! jsonDecoder.decode(PaginationMain.self, from: tempData)
            }
        }
    }
}
